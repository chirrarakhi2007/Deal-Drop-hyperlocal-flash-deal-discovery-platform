const http = require('http');
const fs = require('fs');
const path = require('path');
const config = require('./config');
const logger = require('./logger');
const db = require('./db');
const auth = require('./auth');
const validator = require('./validator');
const rateLimiter = require('./rateLimiter');

function parseUrl(urlStr) {
  const idx = urlStr.indexOf('?');
  if (idx === -1) return { pathname: urlStr, query: {} };
  const pathname = urlStr.substring(0, idx);
  const search = urlStr.substring(idx + 1);
  const query = {};
  for (const pair of search.split('&')) {
    if (pair) {
      const [k, v] = pair.split('=');
      query[decodeURIComponent(k)] = decodeURIComponent(v || '');
    }
  }
  return { pathname, query };
}

function sendJson(res, statusCode, data) {
  res.statusCode = statusCode;
  res.setHeader('Content-Type', 'application/json');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.end(JSON.stringify(data));
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => { body += chunk.toString(); });
    req.on('end', () => {
      if (!body) return resolve({});
      try {
        resolve(JSON.parse(body));
      } catch (err) {
        reject(new Error('Invalid JSON payload'));
      }
    });
    req.on('error', reject);
  });
}

const server = http.createServer(async (req, res) => {
  const { pathname, query } = parseUrl(req.url);

  // CORS preflight
  if (req.method === 'OPTIONS') {
    res.statusCode = 204;
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.end();
    return;
  }

  try {
    // API Routes
    if (pathname === '/api/deals' && req.method === 'GET') {
      let deals = db.getAllDeals();

      if (query.category && query.category !== 'All') {
        deals = deals.filter(d => d.category === query.category);
      }
      if (query.radius) {
        const rad = Number(query.radius);
        if (!isNaN(rad)) {
          deals = deals.filter(d => d.distance_km <= rad);
        }
      }
      if (query.search) {
        const q = query.search.toLowerCase();
        deals = deals.filter(d => d.title.toLowerCase().includes(q) || d.merchant_name.toLowerCase().includes(q));
      }
      if (query.happy_hour === 'true' || query.happy_hour === '1') {
        deals = deals.filter(d => d.is_happy_hour === 1 || d.discount_percent >= 40);
      }

      sendJson(res, 200, deals);
      return;
    }

    if (pathname === '/api/deals' && req.method === 'POST') {
      const decodedToken = auth.authMiddleware(req, res);
      if (!decodedToken) return;

      const body = await readBody(req);
      const valResult = validator.validateDealPayload(body);
      if (!valResult.valid) {
        sendJson(res, 400, { error: 'Validation failed', details: valResult.errors });
        return;
      }

      const newDeal = db.createDeal(valResult.sanitizedPayload);
      logger.info('Created new deal', { id: newDeal.id, title: newDeal.title });
      sendJson(res, 201, newDeal);
      return;
    }

    // Match /api/deals/:id/claim
    if (pathname.startsWith('/api/deals/') && pathname.endsWith('/claim') && req.method === 'POST') {
      const parts = pathname.split('/');
      const dealId = parts[3];

      if (!rateLimiter(req, res, () => {})) {
        return; // Rate limit response sent by middleware
      }

      const userIp = req.headers['x-forwarded-for'] || req.socket?.remoteAddress || '127.0.0.1';
      const claimRes = db.claimVoucherTransaction(dealId, userIp);

      if (!claimRes.success) {
        sendJson(res, claimRes.code || 400, { error: claimRes.message });
        return;
      }

      sendJson(res, 200, claimRes);
      return;
    }

    if (pathname === '/api/analytics' && req.method === 'GET') {
      const stats = db.getAnalytics();
      sendJson(res, 200, stats);
      return;
    }

    if (pathname === '/api/auth/login' && req.method === 'POST') {
      const body = await readBody(req);
      const { username, password } = body;

      if (!username || !password) {
        sendJson(res, 400, { error: 'Username and password are required' });
        return;
      }

      const hashedInput = auth.hashPassword(password);
      if (username === config.ADMIN_USERNAME && hashedInput === config.ADMIN_PASSWORD_HASH) {
        const token = auth.generateToken({ username, role: 'merchant' });
        logger.info('Merchant login successful', { username });
        sendJson(res, 200, { token, token_type: 'Bearer', expires_in: 86400 });
        return;
      } else {
        logger.warn('Merchant login failed', { username });
        sendJson(res, 401, { error: 'Invalid merchant credentials' });
        return;
      }
    }

    // Static File Serving
    let filePath = path.join(__dirname, pathname === '/' ? 'index.html' : pathname);
    if (fs.existsSync(filePath) && fs.statSync(filePath).isFile()) {
      const ext = path.extname(filePath).toLowerCase();
      const contentTypes = {
        '.html': 'text/html',
        '.css': 'text/css',
        '.js': 'application/javascript',
        '.ts': 'application/typescript',
        '.json': 'application/json',
        '.png': 'image/png',
        '.jpg': 'image/jpeg',
        '.svg': 'image/svg+xml'
      };
      res.statusCode = 200;
      res.setHeader('Content-Type', contentTypes[ext] || 'text/plain');
      fs.createReadStream(filePath).pipe(res);
      return;
    }

    sendJson(res, 404, { error: 'Route not found' });
  } catch (err) {
    logger.error('Unhandled server error', { error: err.message, stack: err.stack });
    sendJson(res, 500, { error: 'Internal server error: ' + err.message });
  }
});

if (require.main === module) {
  server.listen(config.PORT, () => {
    logger.info(`DealDrop REST Server running on port ${config.PORT}`);
  });
}

module.exports = server;
