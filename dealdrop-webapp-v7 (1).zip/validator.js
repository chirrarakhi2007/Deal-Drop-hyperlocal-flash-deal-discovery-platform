function sanitize(str) {
  if (typeof str !== 'string') return str;
  return str.replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#x27;');
}

function validateDealPayload(payload) {
  const errors = [];
  if (!payload || typeof payload !== 'object') {
    return { valid: false, errors: ['Payload must be an object'] };
  }

  const { title, category, discount_percent, original_price, deal_price, total_quota, distance_km, expiry_hours } = payload;

  if (!title || typeof title !== 'string' || title.trim().length < 3 || title.trim().length > 100) {
    errors.push('Title must be a string between 3 and 100 characters');
  }

  const validCategories = ['Dining', 'Wellness', 'Fitness', 'Entertainment', 'Services'];
  if (!category || !validCategories.includes(category)) {
    errors.push(`Category must be one of: ${validCategories.join(', ')}`);
  }

  const discount = Number(discount_percent);
  if (isNaN(discount) || discount < 1 || discount > 100) {
    errors.push('Discount percent must be a number between 1 and 100');
  }

  const origPrice = Number(original_price);
  if (isNaN(origPrice) || origPrice <= 0) {
    errors.push('Original price must be a positive number');
  }

  const dPrice = Number(deal_price);
  if (isNaN(dPrice) || dPrice < 0) {
    errors.push('Deal price must be a valid positive number');
  }

  const quota = Number(total_quota);
  if (isNaN(quota) || quota < 1 || !Number.isInteger(quota)) {
    errors.push('Total quota must be a positive integer');
  }

  const dist = Number(distance_km);
  if (isNaN(dist) || dist <= 0 || dist > 50) {
    errors.push('Distance in km must be between 0.1 and 50');
  }

  const hours = Number(expiry_hours || 4);
  if (isNaN(hours) || hours <= 0 || hours > 168) {
    errors.push('Expiry hours must be between 1 and 168');
  }

  if (errors.length > 0) {
    return { valid: false, errors };
  }

  const sanitized = {
    ...payload,
    title: sanitize(payload.title.trim()),
    merchant_name: sanitize((payload.merchant_name || 'Neighborhood Merchant').trim()),
    merchant_district: sanitize((payload.merchant_district || 'Downtown Central').trim()),
    category,
    discount_percent: discount,
    original_price: origPrice,
    deal_price: dPrice,
    total_quota: quota,
    distance_km: dist,
    expiry_hours: hours
  };

  return { valid: true, errors: [], sanitizedPayload: sanitized };
}

module.exports = {
  sanitize,
  validateDealPayload
};
