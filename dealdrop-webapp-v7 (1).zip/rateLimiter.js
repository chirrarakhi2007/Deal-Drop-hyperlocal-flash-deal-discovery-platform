const logger = require('./logger');

const claimsStore = new Map();
const WINDOW_MS = 60 * 1000; // 1 minute
const MAX_CLAIMS = 5; // 5 claims per minute per IP

function rateLimiter(req, res, next) {
  const ip = req.headers['x-forwarded-for'] || req.socket?.remoteAddress || '127.0.0.1';
  const now = Date.now();

  let record = claimsStore.get(ip);
  if (!record) {
    record = [];
    claimsStore.set(ip, record);
  }

  // filter out timestamps outside window
  const validTimestamps = record.filter(ts => now - ts < WINDOW_MS);
  claimsStore.set(ip, validTimestamps);

  if (validTimestamps.length >= MAX_CLAIMS) {
    logger.warn('Rate limit exceeded', { ip });
    res.statusCode = 429;
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify({ error: 'Too Many Requests. Rate limit exceeded (max 5 claims per minute).' }));
    return false;
  }

  validTimestamps.push(now);
  return true;
}

module.exports = rateLimiter;
