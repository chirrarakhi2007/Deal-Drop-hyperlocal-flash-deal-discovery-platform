const fs = require('fs');
const path = require('path');

const logFile = path.join(__dirname, 'server.log');

function log(level, message, meta = {}) {
  const timestamp = new Date().toISOString();
  const entry = { timestamp, level, message, ...meta };
  const str = JSON.stringify(entry);
  console.log(`[${timestamp}] [${level.toUpperCase()}] ${message} ${Object.keys(meta).length ? JSON.stringify(meta) : ''}`);
  try {
    fs.appendFileSync(logFile, str + '\n');
  } catch (err) {
    // fallback
  }
}

module.exports = {
  info: (msg, meta) => log('info', msg, meta),
  warn: (msg, meta) => log('warn', msg, meta),
  error: (msg, meta) => log('error', msg, meta)
};
