const assert = require('assert');
const { DealService } = require('../app');

const mockDeals = [
  { id: '1', title: 'Artisan Coffee', category: 'Dining', distance_km: 0.8, is_happy_hour: 1, discount_percent: 40, expiry_timestamp: Date.now() + 3600000 },
  { id: '2', title: 'Gym Day Pass', category: 'Fitness', distance_km: 2.5, is_happy_hour: 0, discount_percent: 20, expiry_timestamp: Date.now() + 7200000 },
  { id: '3', title: 'Spa Haircut', category: 'Wellness', distance_km: 4.8, is_happy_hour: 0, discount_percent: 15, expiry_timestamp: Date.now() - 1000 }
];

console.log('==========================================');
console.log(' Running Deal Engine Unit Tests (v7.0)   ');
console.log('==========================================');

// Test 1: Category Filtering
const diningDeals = DealService.filterDeals(mockDeals, { category: 'Dining' });
assert.strictEqual(diningDeals.length, 1);
assert.strictEqual(diningDeals[0].id, '1');
console.log('Test 1: Category Filtering... ✅ Passed!');

// Test 2: Radius Filtering
const nearDeals = DealService.filterDeals(mockDeals, { radiusKm: 3.0 });
assert.strictEqual(nearDeals.length, 2);
console.log('Test 2: Distance Radius Filtering... ✅ Passed!');

// Test 3: Happy Hour Trigger Heuristic
const happyDeals = DealService.filterDeals(mockDeals, { happyHourOnly: true });
assert.strictEqual(happyDeals.length, 1);
assert.strictEqual(happyDeals[0].id, '1');
console.log('Test 3: Happy Hour Filter... ✅ Passed!');

// Test 4: Countdown Urgency Timer
const timerInfo = DealService.calculateRemainingTime(Date.now() + 3660000);
assert.strictEqual(timerInfo.isExpired, false);
assert.strictEqual(timerInfo.hours, 1);
console.log('Test 4: Countdown Urgency Timer... ✅ Passed!');

// Test 5: Anti-Hoarding Voucher Pool
const vouchers = [
  { code: 'VCH-1', claimedAt: Date.now() - 1000 },
  { code: 'VCH-2', claimedAt: Date.now() - (3 * 3600 * 1000) }
];
const poolRes = DealService.processAntiHoardingPool(vouchers);
assert.strictEqual(poolRes.active.length, 1);
assert.strictEqual(poolRes.expiredCount, 1);
console.log('Test 5: Anti-Hoarding Pool... ✅ Passed!');

console.log('------------------------------------------');
console.log('All 5 Unit Test Cases Executed Successfully! 🚀\n');
