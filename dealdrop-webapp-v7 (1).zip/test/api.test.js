const assert = require('assert');
const server = require('../server');
const config = require('../config');
const auth = require('../auth');

function request(method, path, headers = {}, body = null) {
  return new Promise((resolve, reject) => {
    const req = server.emit ? null : null; // server instance
    const options = {
      hostname: '127.0.0.1',
      port: 3001,
      path: path,
      method: method,
      headers: {
        'Content-Type': 'application/json',
        ...headers
      }
    };

    const http = require('http');
    const clientReq = http.request(options, (res) => {
      let data = '';
      res.on('data', chunk => { data += chunk.toString(); });
      res.on('end', () => {
        let json = null;
        try { json = JSON.parse(data); } catch(e) {}
        resolve({ statusCode: res.statusCode, body: json || data });
      });
    });

    clientReq.on('error', reject);
    if (body) {
      clientReq.write(JSON.stringify(body));
    }
    clientReq.end();
  });
}

async function runApiTests() {
  console.log('==========================================');
  console.log(' Running REST API Integration Tests      ');
  console.log('==========================================');

  await new Promise(res => server.listen(3001, res));

  try {
    // API Test 1: GET /api/deals
    const resDeals = await request('GET', '/api/deals');
    assert.strictEqual(resDeals.statusCode, 200);
    assert.ok(Array.isArray(resDeals.body));
    assert.ok(resDeals.body.length >= 16);
    console.log('API Test 1: GET /api/deals... ✅ Passed!');

    // API Test 2: POST /api/auth/login
    const resLogin = await request('POST', '/api/auth/login', {}, { username: 'admin', password: 'password123' });
    assert.strictEqual(resLogin.statusCode, 200);
    assert.ok(resLogin.body.token);
    const validToken = resLogin.body.token;
    console.log('API Test 2: POST /api/auth/login... ✅ Passed!');

    // API Test 3: 401 Unauthorized Rejection
    const resUnauth = await request('POST', '/api/deals', {}, { title: 'Test Deal' });
    assert.strictEqual(resUnauth.statusCode, 401);
    console.log('API Test 3: 401 Unauthorized Rejection... ✅ Passed!');

    // API Test 4: 400 Malformed Payload Rejection
    const resBadVal = await request('POST', '/api/deals', { 'Authorization': `Bearer ${validToken}` }, { title: 'AB' });
    assert.strictEqual(resBadVal.statusCode, 400);
    console.log('API Test 4: 400 Malformed Payload Rejection... ✅ Passed!');

    // API Test 5: Atomic Voucher Claim
    const resClaim = await request('POST', '/api/deals/deal-1/claim');
    assert.strictEqual(resClaim.statusCode, 200);
    assert.ok(resClaim.body.voucherCode);
    console.log('API Test 5: Atomic Voucher Claim... ✅ Passed!');

    // API Test 6: Rate Limiter 429 Rejection
    let lastStatus = 200;
    for (let i = 0; i < 6; i++) {
      const r = await request('POST', '/api/deals/deal-2/claim');
      lastStatus = r.statusCode;
    }
    assert.strictEqual(lastStatus, 429);
    console.log('API Test 6: Rate Limiter 429 Rejection... ✅ Passed!');

    // API Test 7: GET /api/analytics
    const resStats = await request('GET', '/api/analytics');
    assert.strictEqual(resStats.statusCode, 200);
    assert.ok(resStats.body.total_views > 0);
    console.log('API Test 7: GET /api/analytics... ✅ Passed!');

    console.log('------------------------------------------');
    console.log('All REST API Integration Tests Passed! 🚀\n');
  } finally {
    server.close();
  }
}

if (require.main === module) {
  runApiTests().catch(err => {
    console.error('API Tests Failed:', err);
    process.exit(1);
  });
}

module.exports = { runApiTests };
