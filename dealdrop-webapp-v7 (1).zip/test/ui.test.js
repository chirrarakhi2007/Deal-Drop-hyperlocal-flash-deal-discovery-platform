const assert = require('assert');
const { DealService } = require('../app');

console.log('==========================================');
console.log(' Running Frontend UI Component DOM Tests ');
console.log('==========================================');

// UI Test 1: Happy Hour Badge Detection
const deal1 = { discount_percent: 45, is_happy_hour: 1 };
assert.strictEqual(DealService.isHappyHourDeal(deal1), true);
console.log('UI Test 1: Happy Hour Badge Detection... ✅ Passed!');

// UI Test 2: Quota Progress Bar Fill % Calculation
const total = 20;
const remaining = 8;
const fillPct = Math.round((remaining / total) * 100);
assert.strictEqual(fillPct, 40);
console.log('UI Test 2: Quota Fill Calculation (40%)... ✅ Passed!');

// UI Test 3: Search Input Matching
const deals = [
  { title: 'Artisan Pastry Deal', merchant_name: 'Bakery' },
  { title: 'Gym Workout Pass', merchant_name: 'Fitness World' }
];
const searchRes = DealService.filterDeals(deals, { searchKeyword: 'pastry' });
assert.strictEqual(searchRes.length, 1);
assert.strictEqual(searchRes[0].merchant_name, 'Bakery');
console.log('UI Test 3: Search Input Filter Matching... ✅ Passed!');

console.log('------------------------------------------');
console.log('All UI DOM Component Tests Executed Successfully! 🚀\n');
