# DealDrop v7.0 REST API Documentation

## Authentication
Merchant endpoints (`POST /api/deals`) require a JWT Bearer token in the `Authorization` header:
`Authorization: Bearer <your_jwt_token>`

Obtain a token via `POST /api/auth/login`.

## Endpoints

### 1. `GET /api/deals`
Returns all active neighborhood flash deals.
- **Query Parameters**:
  - `category` (optional): `Dining`, `Wellness`, `Fitness`, `Entertainment`, `Services`
  - `radius` (optional): `1`, `3`, `5` (distance in km)
  - `search` (optional): Keyword search string
  - `happy_hour` (optional): `true` or `1`
- **Response**: `200 OK` Array of deal objects.

### 2. `POST /api/auth/login`
Authenticates merchant and returns JWT token.
- **Payload**:
  ```json
  {
    "username": "admin",
    "password": "password123"
  }
  ```
- **Response**: `200 OK`
  ```json
  {
    "token": "eyJhbGciOiJIUzI1Ni...",
    "token_type": "Bearer",
    "expires_in": 86400
  }
  ```

### 3. `POST /api/deals`
Publishes a new flash deal (Merchant Authenticated).
- **Headers**: `Authorization: Bearer <token>`
- **Payload**:
  ```json
  {
    "title": "50% Off Fresh Pastries",
    "category": "Dining",
    "discount_percent": 50,
    "original_price": 20,
    "deal_price": 10,
    "total_quota": 20,
    "distance_km": 1.2,
    "expiry_hours": 4
  }
  ```

### 4. `POST /api/deals/:id/claim`
Claims a single voucher token using atomic SQLite transactions.
- **Rate Limit**: Max 5 claims per minute per IP.
- **Response**: `200 OK`
  ```json
  {
    "success": true,
    "voucherCode": "DEALDROP-A1B2-C3D4",
    "expiresAt": 1770000000000,
    "remainingQuota": 14
  }
  ```

### 5. `GET /api/analytics`
Returns pre-aggregated campaign performance statistics in $O(1)$ constant time.
