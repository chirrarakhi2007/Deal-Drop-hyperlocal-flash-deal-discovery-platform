const { DatabaseSync } = require('node:sqlite');
const path = require('path');
const fs = require('fs');
const config = require('./config');
const logger = require('./logger');

const dbPath = path.isAbsolute(config.DB_PATH) ? config.DB_PATH : path.join(__dirname, config.DB_PATH);
const db = new DatabaseSync(dbPath);

function initDb() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS deals (
      id TEXT PRIMARY KEY,
      merchant_name TEXT NOT NULL,
      merchant_district TEXT NOT NULL,
      title TEXT NOT NULL,
      category TEXT NOT NULL,
      discount_percent REAL NOT NULL,
      original_price REAL NOT NULL,
      deal_price REAL NOT NULL,
      distance_km REAL NOT NULL,
      total_quota INTEGER NOT NULL,
      remaining_quota INTEGER NOT NULL,
      expiry_timestamp INTEGER NOT NULL,
      image_emoji TEXT,
      is_happy_hour INTEGER DEFAULT 0,
      lat REAL DEFAULT 37.7749,
      lng REAL DEFAULT -122.4194,
      created_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS vouchers (
      id TEXT PRIMARY KEY,
      deal_id TEXT NOT NULL,
      voucher_code TEXT NOT NULL,
      claimed_at INTEGER NOT NULL,
      expires_at INTEGER NOT NULL,
      status TEXT DEFAULT 'active',
      user_ip TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS analytics_summary (
      id INTEGER PRIMARY KEY CHECK (id = 1),
      total_views INTEGER DEFAULT 0,
      total_claims INTEGER DEFAULT 0,
      total_savings REAL DEFAULT 0.0,
      estimated_walkins INTEGER DEFAULT 0
    );
  `);

  // Initialize summary row if not exists
  const row = db.prepare('SELECT id FROM analytics_summary WHERE id = 1').get();
  if (!row) {
    db.prepare('INSERT INTO analytics_summary (id, total_views, total_claims, total_savings, estimated_walkins) VALUES (1, 142, 86, 1285.50, 73)').run();
  }

  // Check if deals table is empty, if so, seed from deals.json
  const dealCountRow = db.prepare('SELECT COUNT(*) as count FROM deals').get();
  if (dealCountRow.count === 0) {
    seedDeals();
  }
}

function seedDeals() {
  const dealsJsonPath = path.join(__dirname, 'deals.json');
  if (fs.existsSync(dealsJsonPath)) {
    const raw = fs.readFileSync(dealsJsonPath, 'utf8');
    const items = JSON.parse(raw);
    const insertStmt = db.prepare(`
      INSERT INTO deals (
        id, merchant_name, merchant_district, title, category,
        discount_percent, original_price, deal_price, distance_km,
        total_quota, remaining_quota, expiry_timestamp, image_emoji,
        is_happy_hour, lat, lng, created_at
      ) VALUES (
        ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
      )
    `);

    const now = Date.now();
    for (const item of items) {
      const expiry = item.expiry_hours ? (now + item.expiry_hours * 3600 * 1000) : (now + 6 * 3600 * 1000);
      insertStmt.run(
        item.id,
        item.merchant_name,
        item.merchant_district,
        item.title,
        item.category,
        item.discount_percent,
        item.original_price,
        item.deal_price,
        item.distance_km,
        item.total_quota,
        item.remaining_quota,
        expiry,
        item.image_emoji || '🏷️',
        item.is_happy_hour || 0,
        item.lat || 37.7749,
        item.lng || -122.4194,
        now
      );
    }
    logger.info('Seeded deals database with 16 neighborhood flash offers.');
  }
}

initDb();

function getAllDeals() {
  // increment total_views in analytics
  db.prepare('UPDATE analytics_summary SET total_views = total_views + 1 WHERE id = 1').run();
  return db.prepare('SELECT * FROM deals ORDER BY created_at DESC').all();
}

function getDealById(id) {
  return db.prepare('SELECT * FROM deals WHERE id = ?').get(id);
}

function createDeal(dealData) {
  const id = 'deal-' + Date.now();
  const now = Date.now();
  const expiry = now + (dealData.expiry_hours || 4) * 3600 * 1000;
  const isHappyHour = (dealData.discount_percent >= 40) ? 1 : 0;

  db.prepare(`
    INSERT INTO deals (
      id, merchant_name, merchant_district, title, category,
      discount_percent, original_price, deal_price, distance_km,
      total_quota, remaining_quota, expiry_timestamp, image_emoji,
      is_happy_hour, lat, lng, created_at
    ) VALUES (
      ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
    )
  `).run(
    id,
    dealData.merchant_name || 'Neighborhood Merchant',
    dealData.merchant_district || 'Downtown Central',
    dealData.title,
    dealData.category,
    dealData.discount_percent,
    dealData.original_price,
    dealData.deal_price,
    dealData.distance_km,
    dealData.total_quota,
    dealData.total_quota, // initial remaining = total
    expiry,
    dealData.image_emoji || '🔥',
    isHappyHour,
    dealData.lat || 37.7749,
    dealData.lng || -122.4194,
    now
  );

  return getDealById(id);
}

// ATOMIC TRANSACTION for claiming vouchers
function claimVoucherTransaction(dealId, userIp) {
  db.exec('BEGIN IMMEDIATE');
  try {
    const deal = db.prepare('SELECT * FROM deals WHERE id = ?').get(dealId);
    if (!deal) {
      db.exec('ROLLBACK');
      return { success: false, code: 404, message: 'Deal not found' };
    }

    if (deal.remaining_quota <= 0) {
      db.exec('ROLLBACK');
      return { success: false, code: 400, message: 'Deal quota exhausted' };
    }

    if (deal.expiry_timestamp <= Date.now()) {
      db.exec('ROLLBACK');
      return { success: false, code: 400, message: 'Deal has expired' };
    }

    // Decrement quota
    db.prepare('UPDATE deals SET remaining_quota = remaining_quota - 1 WHERE id = ?').run(dealId);

    // Generate voucher code
    const tokenPart = Math.random().toString(36).substring(2, 6).toUpperCase();
    const codePart = Math.random().toString(36).substring(2, 6).toUpperCase();
    const voucherCode = `DEALDROP-${tokenPart}-${codePart}`;
    const voucherId = 'vch-' + Date.now() + '-' + Math.floor(Math.random()*1000);
    const now = Date.now();
    const expiresAt = now + (2 * 3600 * 1000); // 2-hour anti-hoarding pool window

    db.prepare(`
      INSERT INTO vouchers (id, deal_id, voucher_code, claimed_at, expires_at, status, user_ip)
      VALUES (?, ?, ?, ?, ?, 'active', ?)
    `).run(voucherId, dealId, voucherCode, now, expiresAt, userIp);

    // O(1) Pre-aggregated Analytics Update
    const savings = Number((deal.original_price - deal.deal_price).toFixed(2));
    db.prepare(`
      UPDATE analytics_summary
      SET total_claims = total_claims + 1,
          total_savings = total_savings + ?,
          estimated_walkins = CAST((total_claims + 1) * 0.85 AS INTEGER)
      WHERE id = 1
    `).run(savings);

    db.exec('COMMIT');
    logger.info('Voucher claimed successfully', { dealId, voucherCode, userIp });

    return {
      success: true,
      voucherCode,
      expiresAt,
      remainingQuota: deal.remaining_quota - 1,
      dealTitle: deal.title,
      merchantName: deal.merchant_name
    };
  } catch (err) {
    db.exec('ROLLBACK');
    logger.error('Voucher claim transaction failed', { error: err.message });
    return { success: false, code: 500, message: 'Transaction error: ' + err.message };
  }
}

function getAnalytics() {
  const summary = db.prepare('SELECT * FROM analytics_summary WHERE id = 1').get();
  const dealStats = db.prepare('SELECT COUNT(*) as total_deals, SUM(total_quota - remaining_quota) as total_claimed_from_deals FROM deals').get();

  return {
    total_views: summary ? summary.total_views : 0,
    total_claims: summary ? summary.total_claims : 0,
    total_savings: summary ? Number(summary.total_savings.toFixed(2)) : 0,
    estimated_walkins: summary ? summary.estimated_walkins : 0,
    active_deals_count: dealStats ? dealStats.total_deals : 0,
    conversion_rate_percent: summary && summary.total_views > 0 ? Number(((summary.total_claims / summary.total_views) * 100).toFixed(1)) : 0
  };
}

module.exports = {
  getAllDeals,
  getDealById,
  createDeal,
  claimVoucherTransaction,
  getAnalytics
};
