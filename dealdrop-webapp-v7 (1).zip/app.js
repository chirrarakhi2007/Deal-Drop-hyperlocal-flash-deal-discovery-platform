class DealService {
  static calculateDistance(lat1, lon1, lat2, lon2) {
    const R = 6371;
    const dLat = (lat2 - lat1) * (Math.PI / 180);
    const dLon = (lon2 - lon1) * (Math.PI / 180);
    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
              Math.cos(lat1 * (Math.PI / 180)) * Math.cos(lat2 * (Math.PI / 180)) *
              Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return Number((R * c).toFixed(1));
  }

  static filterDeals(deals, options) {
    return deals.filter(deal => {
      if (options.category && options.category !== 'All' && deal.category !== options.category) {
        return false;
      }
      if (options.radiusKm && deal.distance_km > options.radiusKm) {
        return false;
      }
      if (options.searchKeyword) {
        const q = options.searchKeyword.toLowerCase();
        const matchTitle = deal.title.toLowerCase().includes(q);
        const matchMerchant = deal.merchant_name.toLowerCase().includes(q);
        if (!matchTitle && !matchMerchant) return false;
      }
      if (options.happyHourOnly && !this.isHappyHourDeal(deal)) {
        return false;
      }
      return true;
    });
  }

  static isHappyHourDeal(deal) {
    return deal.is_happy_hour === 1 || deal.discount_percent >= 40;
  }

  static calculateRemainingTime(expiryTimestamp) {
    const now = Date.now();
    const diff = expiryTimestamp - now;
    if (diff <= 0) {
      return { hours: 0, minutes: 0, seconds: 0, isExpired: true, formatted: 'Expired' };
    }
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((diff % (1000 * 60)) / 1000);
    const formatted = `${hours}h ${minutes}m ${seconds}s`;
    return { hours, minutes, seconds, isExpired: false, formatted };
  }

  static processAntiHoardingPool(claimedVouchers) {
    const now = Date.now();
    const TWO_HOURS = 2 * 3600 * 1000;
    const active = claimedVouchers.filter(v => now - v.claimedAt < TWO_HOURS);
    const expiredCount = claimedVouchers.length - active.length;
    return { active, expiredCount };
  }
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { DealService };
}

if (typeof window !== 'undefined' && typeof document !== 'undefined') {
  document.addEventListener('DOMContentLoaded', () => {
    let allDeals = [];
    let selectedCategory = 'All';
    let selectedRadius = 5;
    let searchKeyword = '';
    let happyHourFilter = false;
    let jwtToken = localStorage.getItem('dealdrop_merchant_token') || null;
    let mapInstance = null;
    let mapMarkers = [];

    const dealsGrid = document.getElementById('deals-grid');
    const searchInput = document.getElementById('search-input');
    const happyHourBtn = document.getElementById('happy-hour-btn');

    async function fetchDeals() {
      try {
        const res = await fetch('/api/deals');
        if (res.ok) {
          allDeals = await res.json();
          renderDeals();
          renderMap();
        }
      } catch (err) {
        console.error('Error fetching deals:', err);
      }
    }

    function renderDeals() {
      if (!dealsGrid) return;
      const filtered = DealService.filterDeals(allDeals, {
        category: selectedCategory,
        radiusKm: selectedRadius,
        searchKeyword: searchKeyword,
        happyHourOnly: happyHourFilter
      });

      if (filtered.length === 0) {
        dealsGrid.innerHTML = `
          <div class="empty-state">
            <div style="font-size: 3rem;">🔍</div>
            <h3>No Flash Deals Found</h3>
            <p>Try widening your distance radius or selecting a different category.</p>
          </div>
        `;
        return;
      }

      dealsGrid.innerHTML = filtered.map(deal => {
        const timeInfo = DealService.calculateRemainingTime(deal.expiry_timestamp);
        const quotaPct = Math.round((deal.remaining_quota / deal.total_quota) * 100);
        const isUrgent = timeInfo.hours === 0 && !timeInfo.isExpired;
        const isHappy = DealService.isHappyHourDeal(deal);

        return `
          <div class="deal-card ${isHappy ? 'happy-hour-card' : ''}">
            <div class="card-header">
              <span class="emoji-icon">${deal.image_emoji || '🏷️'}</span>
              <span class="discount-badge">-${deal.discount_percent}% OFF</span>
              ${isHappy ? '<span class="happy-tag">⚡ Happy Hour</span>' : ''}
            </div>
            <div class="card-body">
              <div class="merchant-meta">
                <span class="merchant-name">${deal.merchant_name}</span>
                <span class="district-name">📍 ${deal.merchant_district} (${deal.distance_km} km)</span>
              </div>
              <h3 class="deal-title">${deal.title}</h3>
              <div class="price-row">
                <span class="deal-price">$${deal.deal_price.toFixed(2)}</span>
                <span class="original-price">$${deal.original_price.toFixed(2)}</span>
                <span class="category-pill">${deal.category}</span>
              </div>
              <div class="timer-box ${isUrgent ? 'timer-urgent' : ''}">
                ⏳ Ends in: <strong id="timer-${deal.id}">${timeInfo.formatted}</strong>
              </div>
              <div class="quota-container">
                <div class="quota-label">
                  <span>Quota remaining:</span>
                  <strong>${deal.remaining_quota} of ${deal.total_quota} left</strong>
                </div>
                <div class="quota-bar">
                  <div class="quota-fill ${quotaPct < 30 ? 'low-quota' : ''}" style="width: ${quotaPct}%;"></div>
                </div>
              </div>
              <button class="claim-btn ${deal.remaining_quota <= 0 ? 'disabled' : ''}" 
                onclick="window.claimVoucher('${deal.id}')"
                ${deal.remaining_quota <= 0 ? 'disabled' : ''}>
                ${deal.remaining_quota <= 0 ? 'Exhausted' : 'Claim Deal & Copy Code'}
              </button>
            </div>
          </div>
        `;
      }).join('');
    }

    function renderMap() {
      const mapElem = document.getElementById('deal-map');
      if (!mapElem || typeof L === 'undefined') return;

      if (!mapInstance) {
        mapInstance = L.map('deal-map').setView([37.7749, -122.4194], 13);
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
          attribution: '&copy; OpenStreetMap contributors'
        }).addTo(mapInstance);
      }

      // Clear existing markers
      mapMarkers.forEach(m => mapInstance.removeLayer(m));
      mapMarkers = [];

      const filtered = DealService.filterDeals(allDeals, {
        category: selectedCategory,
        radiusKm: selectedRadius,
        searchKeyword: searchKeyword,
        happyHourOnly: happyHourFilter
      });

      filtered.forEach(deal => {
        const marker = L.marker([deal.lat || 37.7749, deal.lng || -122.4194]).addTo(mapInstance);
        marker.bindPopup(`
          <div style="font-family: sans-serif; text-align: center;">
            <strong>${deal.merchant_name}</strong><br/>
            <span>${deal.title}</span><br/>
            <strong style="color: #4f46e5;">-${deal.discount_percent}% OFF</strong>
          </div>
        `);
        mapMarkers.push(marker);
      });
    }

    // Category Tabs Event
    document.querySelectorAll('.cat-tab').forEach(tab => {
      tab.addEventListener('click', (e) => {
        document.querySelectorAll('.cat-tab').forEach(t => t.classList.remove('active'));
        e.target.classList.add('active');
        selectedCategory = e.target.dataset.cat;
        renderDeals();
        renderMap();
      });
    });

    // Radius Buttons Event
    document.querySelectorAll('.radius-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        document.querySelectorAll('.radius-btn').forEach(b => b.classList.remove('active'));
        e.target.classList.add('active');
        selectedRadius = Number(e.target.dataset.rad);
        renderDeals();
        renderMap();
      });
    });

    // Search Input Event
    if (searchInput) {
      searchInput.addEventListener('input', (e) => {
        searchKeyword = e.target.value.trim();
        renderDeals();
        renderMap();
      });
    }

    // Happy Hour Filter Button Event
    if (happyHourBtn) {
      happyHourBtn.addEventListener('click', () => {
        happyHourFilter = !happyHourFilter;
        happyHourBtn.classList.toggle('active', happyHourFilter);
        renderDeals();
        renderMap();
      });
    }

    // Live Expiration Timer Tick Interval
    setInterval(() => {
      allDeals.forEach(deal => {
        const elem = document.getElementById(`timer-${deal.id}`);
        if (elem) {
          const info = DealService.calculateRemainingTime(deal.expiry_timestamp);
          elem.textContent = info.formatted;
        }
      });
    }, 1000);

    // Global Voucher Claim Function
    window.claimVoucher = async function(dealId) {
      try {
        const res = await fetch(`/api/deals/${dealId}/claim`, { method: 'POST' });
        const data = await res.json();
        if (res.ok && data.success) {
          // Copy code to clipboard
          navigator.clipboard.writeText(data.voucherCode).catch(() => {});
          
          // Show Voucher Modal
          const modal = document.getElementById('voucher-modal');
          const codeElem = document.getElementById('modal-voucher-code');
          const merchantElem = document.getElementById('modal-merchant-name');
          const shareBtn = document.getElementById('whatsapp-share-btn');

          if (codeElem) codeElem.textContent = data.voucherCode;
          if (merchantElem) merchantElem.textContent = data.merchantName || 'Neighborhood Merchant';
          if (shareBtn) {
            const shareText = encodeURIComponent(`Check out this deal at ${data.merchantName}! Use code: ${data.voucherCode} on DealDrop!`);
            shareBtn.href = `https://api.whatsapp.com/send?text=${shareText}`;
          }

          if (modal) modal.style.display = 'flex';

          // Refresh deals
          fetchDeals();
          fetchAnalytics();
        } else {
          alert(data.error || 'Unable to claim deal.');
        }
      } catch (err) {
        alert('Network error claiming voucher.');
      }
    };

    // Close Modal
    document.querySelectorAll('.close-modal').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.modal').forEach(m => m.style.display = 'none');
      });
    });

    // Fetch analytics for dashboard
    async function fetchAnalytics() {
      try {
        const res = await fetch('/api/analytics');
        if (res.ok) {
          const data = await res.json();
          const viewsElem = document.getElementById('stat-views');
          const claimsElem = document.getElementById('stat-claims');
          const savingsElem = document.getElementById('stat-savings');
          const walkinsElem = document.getElementById('stat-walkins');

          if (viewsElem) viewsElem.textContent = data.total_views;
          if (claimsElem) claimsElem.textContent = data.total_claims;
          if (savingsElem) savingsElem.textContent = `$${data.total_savings.toFixed(2)}`;
          if (walkinsElem) walkinsElem.textContent = data.estimated_walkins;
        }
      } catch (err) {}
    }

    // Initial Load
    fetchDeals();
    fetchAnalytics();
  });
}
