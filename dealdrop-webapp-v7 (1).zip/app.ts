export interface Deal {
  id: string;
  merchant_name: string;
  merchant_district: string;
  title: string;
  category: 'Dining' | 'Wellness' | 'Fitness' | 'Entertainment' | 'Services';
  discount_percent: number;
  original_price: number;
  deal_price: number;
  distance_km: number;
  total_quota: number;
  remaining_quota: number;
  expiry_timestamp: number;
  image_emoji: string;
  is_happy_hour: number;
  lat: number;
  lng: number;
}

export interface FilterOptions {
  category?: string;
  radiusKm?: number;
  searchKeyword?: string;
  happyHourOnly?: boolean;
}

export class DealService {
  public static calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
    const R = 6371; // km
    const dLat = (lat2 - lat1) * (Math.PI / 180);
    const dLon = (lon2 - lon1) * (Math.PI / 180);
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(lat1 * (Math.PI / 180)) * Math.cos(lat2 * (Math.PI / 180)) *
      Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return Number((R * c).toFixed(1));
  }

  public static filterDeals(deals: Deal[], options: FilterOptions): Deal[] {
    return deals.filter(deal => {
      if (options.category && options.category !== 'All' && deal.category !== options.category) {
        return false;
      }
      if (options.radiusKm && deal.distance_km > options.radiusKm) {
        return false;
      }
      if (options.searchKeyword) {
        const q = options.searchKeyword.toLowerCase();
        const matchTitle = deal.title.toLowerCase().includes(q);
        const matchMerchant = deal.merchant_name.toLowerCase().includes(q);
        if (!matchTitle && !matchMerchant) return false;
      }
      if (options.happyHourOnly && !this.isHappyHourDeal(deal)) {
        return false;
      }
      return true;
    });
  }

  public static isHappyHourDeal(deal: Deal): boolean {
    return deal.is_happy_hour === 1 || deal.discount_percent >= 40;
  }

  public static calculateRemainingTime(expiryTimestamp: number): { hours: number; minutes: number; seconds: number; isExpired: boolean; formatted: string } {
    const now = Date.now();
    const diff = expiryTimestamp - now;
    if (diff <= 0) {
      return { hours: 0, minutes: 0, seconds: 0, isExpired: true, formatted: 'Expired' };
    }
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((diff % (1000 * 60)) / 1000);
    const formatted = `${hours}h ${minutes}m ${seconds}s`;
    return { hours, minutes, seconds, isExpired: false, formatted };
  }

  public static processAntiHoardingPool(claimedVouchers: { code: string; claimedAt: number }[]): { active: any[]; expiredCount: number } {
    const now = Date.now();
    const TWO_HOURS = 2 * 3600 * 1000;
    const active = claimedVouchers.filter(v => now - v.claimedAt < TWO_HOURS);
    const expiredCount = claimedVouchers.length - active.length;
    return { active, expiredCount };
  }
}
